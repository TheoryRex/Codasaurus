#Dr. Richard Watson, Dr. Xia Zhao, Yuanyuan Song, Nathaniel Kelley, Isaiah S. Williams
#Author: Nathaniel Kelley
#Nathaniel Kelley is a research assistant at the University of Georgia, Terry College of Business (2020-2021) and the author of the first version of Codasaurus.
#Author email: nkelley1998'gmail.com
#Sponsor email: rwatson'uga.edu
#T-Rex Research team at the University of Georgia, Terry College of Business

#Copyright 2021 University of Georgia, Terry College of Business

#This file is part of Codasaurus.

#Codasaurus is free software: you can redistribute it and/or modify
#it under the terms of the GNU Affero General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.

#Codasaurus is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU Affero General Public License for more details.

#You should have received a copy of the GNU Affero General Public License
#along with Codasaurus.  If not, see <https://www.gnu.org/licenses/>.

############################################################################

#In this script include all the server side functions: plots, reactive objects, etc.

#Defining functions
to_null <- function(x){
  if(x == "") return("NULL")
  else return(paste0('"',x,'"'))
}


## Define a server for the Shiny app
function(input, output, session) {
  
  # Empty list to store parameters(ie elements, authors,..) text input values
  parameters <- reactiveValues()
  
  downloadStore <- reactiveValues()
  
  ############################################################################
  observeEvent(input$pub_save_btn, {
    parameters$pubUUID <- UUIDgenerate(FALSE, 1)
    parameters$doi <- NA
    parameters$doi_cr_cn <- NA
    parameters$year <- NA
    #parameters$doi_author <- NA
    # 10.3386/w4509
    if (input$pubTyp == "Manual Pub") {
      parameters$manuCit <- to_null(input$manuCit)
      parameters$year <- stri_extract_first(parameters$manuCit, regex="\\d+")
      output$pub_out <- renderText(paste('CREATE (:Publication {citation: ',parameters$manuCit,', pubUUID: "',parameters$pubUUID, '", year: "',parameters$year,'"});', sep = ""))
      downloadStore$pub_out <- paste('CREATE (:Publication {citation: ',parameters$manuCit,', pubUUID: "',parameters$pubUUID, '", year: "',parameters$year,'"});', sep = "")
    }
    else{
      parameters$doi <- to_null(input$doi)
      parameters$doi_cr_cn <- input$doi
      parameters$year <- stri_extract_first(cr_cn(parameters$doi_cr_cn, "text", "apa"), regex ="\\d+")
      #parameters$doi_author <- cr_works(dois=input$doi)
      output$pub_out <- renderText(paste('CREATE (:Publication {DOI: ',parameters$doi,', citation: "',cr_cn(parameters$doi_cr_cn, "text", "apa"),'", pubUUID: "',parameters$pubUUID, '", year: "',parameters$year,'"});', sep = ""))
      downloadStore$pub_out <- paste('CREATE (:Publication {DOI: ',parameters$doi,', citation: "',cr_cn(parameters$doi_cr_cn, "text", "apa"),'", pubUUID: "',parameters$pubUUID, '", year: "',parameters$year,'"});', sep = "")
      res <- cr_cn(parameters$doi_cr_cn,format = "citeproc-json", raw = F, locale = "en-US")
      authors <- dim(res$author)[1] 
      # Use loop to get each of them
      for(i in 1:authors) {
        orcid <- res$author$ORCID[i]
        given <-  res$author$given[i]
        family <- res$author$family[i]
        
        parameters$authFirst[i] <-given
        #parameters$authMiddle[i] <- to_null(input[[paste0("authMiddle",i)]])
        parameters$authLast[i] <- family
        parameters$orcid[i] <- orcid
        parameters$authOrder[i] <- i
        parameters$authUUID[i] <- to_null(UUIDgenerate(FALSE, 1))
        if(!is.na(res$author$given[i]) & !is.na(res$author$family[i]))  {
          output$auth_list <- renderText(paste("CREATE (:Author {ORCID: '",parameters$orcid,"', authorFirst: '",parameters$authFirst,"', authorLast: '",parameters$authLast,"', authUUID: ",parameters$authUUID,"});",
                                               "MATCH (p:Publication {DOI: ",parameters$doi,"}), (a:Author {ORCID: '",parameters$orcid,"', authorFirst: '",parameters$authFirst,"', authorLast: '",parameters$authLast,"'})
                                             CREATE (p)-[r:WRITTEN_BY {authorOrder: ",parameters$authOrder,"}]->(a)
                                             RETURN r;", sep = ""))
          downloadStore$auth_list <- paste("CREATE (:Author {ORCID: '",parameters$orcid,"', authorFirst: '",parameters$authFirst,"', authorLast: '",parameters$authLast,"', authUUID: ",parameters$authUUID,"});
MATCH (p:Publication {DOI: ",parameters$doi,"}), (a:Author {authUUID:", parameters$authUUID,"})
CREATE (p)-[r:WRITTEN_BY {authorOrder: '",parameters$authOrder,"'}]->(a)
RETURN r;", sep = "")
        } } }
  })
  
  #code to generate publication input boxes
  pubBox <- reactive({
    if (input$pubTyp == "Manual Pub") {
      # If the no. of publication boxes previously where more than zero, then
      #save the text inputs in those text boxes
      manuPubInput<- tagList(
        textInput(inputId = "manuCit",
                  label = "Appropriately cite the publication"))
    }
    else{
      autoPubInput<- tagList(
        textInput(inputId = "doi",
                  label = "Enter the publication's DOI"))
    }
  })
  
  
  
  #display publication input boxes
  output$pub_ui <- renderUI({ pubBox() })
  
  
  ###############################################################################
  observeEvent(input$pubTyp, {
    if(input$pubTyp == "DOI Pub"){
      shinyjs::hide(id = "authorBox")
      #shinyjs::hide(id = "authorBox2")
    }else{
      shinyjs::show(id = "authorBox")
      #shinyjs::show(id = "authorBox2")
    }
  })
  # Track the number of element input boxes to render
  counterElement <- reactiveValues(n = 0)
  
  
  #Track the number of input boxes previously
  prevcountElement <-reactiveValues(n = 0)
  
  #On click: add element input box
  observeEvent(input$ele_add_btn, {
    counterElement$n <- counterElement$n + 1
    prevcountElement$n <- counterElement$n - 1})
  
  #On click: remove last element input box
  # observeEvent(input$ele_rm_btn, {
  # if (counterElement$n > 0) {
  #   counterElement$n <- counterElement$n - 1
  #   prevcountElement$n <- counterElement$n + 1
  # }
  #   for(i in 1:counterElement$n) {
  #     #print(x)
  #     if (parameters$elementName[i] == input$test1)
  #     {
  #       
  #         parameters$elementName[i] <- NA
  #         parameters$elementType[i] <- input[[paste0("elementType",i)]]
  #         #parameters$elementRole[i] <- input[[paste0("elementRole",i)]]
  #         parameters$elementName_select[i] <- input[[paste0("elementName",i)]]
  #         parameters$defFull[i] <- to_null(input[[paste0("defFull",i)]])
  #         #parameters$defEle[i] <- to_null(input[[paste0("defEle",i)]])
  #         parameters$defUUID[i] <- to_null(UUIDgenerate(FALSE,1))
  #         #parameters$elementUUID[i] <- UUIDgenerate(FALSE, 1)
  #       }
  #   }
  # })
  # 
  #On click: store values from element input boxes in a list within parameters list
  observeEvent(input$ele_save_btn, {
    if (counterElement$n > 0) {
      parameters$elementName <- NA
      parameters$elementType <- NA
      #parameters$defEle <- NA
      parameters$defFull <- NA
      parameters$defUUID <- NA
      #parameters$elementRole <- NA
      #parameters$elementUUID <- NA
      for(i in 1:counterElement$n) {
        parameters$elementName[i] <- to_null(input[[paste0("elementName",i)]])
        parameters$elementType[i] <- input[[paste0("elementType",i)]]
        #parameters$elementRole[i] <- input[[paste0("elementRole",i)]]
        parameters$elementName_select[i] <- input[[paste0("elementName",i)]]
        parameters$defFull[i] <- to_null(input[[paste0("defFull",i)]])
        #parameters$defEle[i] <- to_null(input[[paste0("defEle",i)]])
        parameters$defUUID[i] <- to_null(UUIDgenerate(FALSE,1))
        #parameters$elementUUID[i] <- UUIDgenerate(FALSE, 1)
      }
      
      output$element_list <- renderText(paste('CREATE (:Element {elementName: ',parameters$elementName,', elementType: "',parameters$elementType, '"}); CREATE (:Definition {definition: ',parameters$defFull, ", defUUID: ",parameters$defUUID,"});",
                                              "MATCH (p:Publication {pubUUID: '",parameters$pubUUID,"'}), (a:Definition {defUUID: ",parameters$defUUID,"})
                                            CREATE (p)-[r:DEFINES]->(a) RETURN r;",
                                              "MATCH (a:Element {elementName: ",parameters$elementName,"}), (b:Definition {defUUID: ",parameters$defUUID,"})
                                            CREATE (a)-[r:DEFINED_AS]->(b) RETURN r;", sep = ""))
      
      downloadStore$element_list <- paste('CREATE (:Element {elementName: ',parameters$elementName,', elementType: "',parameters$elementType, '"}); CREATE (:Definition {definition: ',parameters$defFull, ", defUUID: ",parameters$defUUID,"});",
                                          "MATCH (p:Publication {pubUUID: '",parameters$pubUUID,"'}), (a:Definition {defUUID: ",parameters$defUUID,"})
                                            CREATE (p)-[r:DEFINES]->(a) RETURN r;",
                                          "MATCH (a:Element {elementName: ",parameters$elementName,"}), (b:Definition {defUUID: ",parameters$defUUID,"})
                                            CREATE (a)-[r:DEFINED_AS]->(b) RETURN r;", sep = "")
      
      
      
      
      
      
      
      
    }
    if (counterElement$n == 0) {
      downloadStore$element_list <- paste(" ")
      output$element_list <-  renderText(paste( " "))
    }
  })
  
  #Store number of element input boxes
  output$counterElement <- renderPrint(print(counterElement$n))
  
  #code to generate element input boxes
  elementboxes <- reactive({
    
    n <- counterElement$n
    
    if (n > 0) {
      # If the no. of element boxes previously were more than zero, then
      #save the text inputs in those text boxes
      if(prevcountElement$n > 0){
        
        vals = c()
        typ = c()
        role = c()
        dFull = c()
        #dEle = c()
        
        if(prevcountElement$n > n){
          lesscnt <- n
          isInc <- FALSE
          
        }else{
          lesscnt <- prevcountElement$n
          isInc <- TRUE
          
        }
        for(i in 1:lesscnt){
          inpid = paste0("elementName",i)
          vals[i] = input[[inpid]]
          inptyp = paste0("elementType",i)
          typ[i] = input[[inptyp]]
          inpDefFull = paste0("defFull",i)
          dFull[i]=input[[inpDefFull]]
          
          #inprole = paste0("elementRole",i)
          #role[i] = input[[inprole]]
        }
        if(isInc){
          vals <- c(vals, input[[paste0("elementName",n)]])
          typ <- c(typ, input[[paste0("elementType",n)]])
          dFull <- c(dFull, input[[paste0("defFull",n)]])
          #dEle <- c(dEle, input[[paste0("defEle",n)]])
          #role <- c(role, input[[paste0("elementRole",n)]])
        }
        
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            textInput(inputId = paste0("elementName", i),
                      label = paste0("Element ", i), value = vals[i]),
            selectInput(inputId = paste0("elementType",i), label = paste0("What type of element is element ",i, "?"),
                        c("Construct" = "Construct","Concept" = "Concept","Event" = "Event"), selected = typ[i]),
            textInput(inputId = paste0("defFull", i),
                      label = paste0("What is its definition?"), value = dFull[i])
            #selectInput(inputId = paste0("elementRole",i), label = paste0("What role does element ",i, " have?"),
            #c("No Role" = "NULL","Moderator" = "'Moderator'","Mediator" = "'Mediator'"), selected = role[i]))
          )})
        
      }else{
        
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            textInput(inputId = paste0("elementName", i),
                      label = paste0("Element ", i), value = "New element"),
            selectInput(inputId = paste0("elementType",i), label = paste0("What type of element is element ",i, "?"),
                        c("Construct" = "Construct","Concept" = "Concept","Event" = "Event")),
            textInput(inputId = paste0("defFull", i),
                      label = paste0("What is its definition?"), value = "Definition")
            #selectInput(inputId = paste0("elementRole",i), label = paste0("What role does element ",i, " have?"),
            #c("No Role" = "NULL","Moderator" = "'Moderator'","Mediator" = "'Mediator'")))
          )})
      }
      
    }
    
  })
  observe(
    updateSelectInput(session, "test1", choices = parameters$elementName)
  )
  output$elements <- renderText({
    parameters$elementName
  })
  
  #display element input boxes
  output$element_ui <- renderUI({ elementboxes() })
  
  ############################################################################
  
  #   # Track the number of input boxes to render
  #   counterDef <- reactiveValues(n = 0)
  # 
  #   #Track the number of input boxes previously
  #   prevcountDef <-reactiveValues(n = 0)
  # 
  #   #On click: add  input box
  #   observeEvent(input$def_add_btn, {
  #     counterDef$n <- counterDef$n + 1
  #     prevcountDef$n <- counterDef$n - 1})
  # 
  # 
  #   #On click: remove last input box
  #   observeEvent(input$def_rm_btn, {
  #     if (counterDef$n > 0) {
  #       counterDef$n <- counterDef$n - 1
  #       prevcountDef$n <- counterDef$n + 1
  #     }
  # 
  #   })
  # 
  #   #On click: store values from input boxes in a list within parameters list
  #   observeEvent(input$def_save_btn, {
  #     if (counterDef$n > 0) {
  #       parameters$defEle <- NA
  #       parameters$defFull <- NA
  #       parameters$defUUID <- NA
  #       for(i in 1:counterDef$n) {
  # #       parameters$defName[i] <- input[[paste0("defName",i)]]
  #         parameters$defFull[i] <- to_null(input[[paste0("defFull",i)]])
  #         parameters$defEle[i] <- to_null(input[[paste0("defEle",i)]])
  #         parameters$defUUID[i] <- to_null(UUIDgenerate(FALSE,1))
  #       }
  # 
  #   #    , modelUUID: '",parameters$modelUUID,"'});</b>"
  # 
  #       if(input$pubTyp == "Manual Pub"){
  #         output$def_list <- renderText(paste("CREATE (:Definition {DefinitionName: ",parameters$defEle,", definition: ",parameters$defFull, ", defUUID: ",parameters$defUUID,"});",
  #                                             "MATCH (p:Publication {pubUUID: '",parameters$pubUUID,"'}), (a:Definition {defUUID: ",parameters$defUUID,"})
  #                                             CREATE (p)-[r:DEFINES]->(a) RETURN r;",
  #                                             "MATCH (a:Element {elementName: ",parameters$defEle,"}), (b:Definition {defUUID: ",parameters$defUUID,"})
  #                                             CREATE (a)-[r:DEFINED_AS]->(b) RETURN r;", sep = ""))
  # 
  #         downloadStore$def_list <- paste("CREATE (:Definition {DefinitionName: ",parameters$defEle,", definition: ",parameters$defFull, ", defUUID: ",parameters$defUUID,"});
  # MATCH (p:Publication {pubUUID: '",parameters$pubUUID,"'}), (a:Definition {defUUID: ",parameters$defUUID,"})
  # CREATE (p)-[r:DEFINES]->(a) RETURN r;
  # MATCH (a:Element {elementName: ",parameters$defEle,"}), (b:Definition {defUUID: ",parameters$defUUID,"})
  # CREATE (a)-[r:DEFINED_AS]->(b) RETURN r;", sep = "")
  # 
  # 
  # 
  # 
  # 
  # 
  #       }
  #       else{
  #         output$def_list <- renderText(paste("CREATE (:Definition {DefinitionName: ",parameters$defEle,", definition: ",parameters$defFull, ", defUUID: ",parameters$defUUID,"});",
  #                                             "MATCH (p:Publication {DOI: ",parameters$doi,"}), (a:Definition {defUUID: ",parameters$defUUID,"})
  #                                             CREATE (p)-[r:DEFINES]->(a) RETURN r;",
  #                                             "MATCH (a:Element {elementName: ",parameters$defEle,"}), (b:Definition {defUUID: ",parameters$defUUID,"})
  #                                             CREATE (a)-[r:DEFINED_AS]->(b) RETURN r;", sep = ""))
  # 
  #         downloadStore$def_list <- paste("CREATE (:Definition {DefinitionName: ",parameters$defEle,", definition: ",parameters$defFull, ", defUUID: ",parameters$defUUID,"});
  # MATCH (p:Publication {DOI: ",parameters$doi,"}), (a:Definition {defUUID: ",parameters$defUUID,"})
  # CREATE (p)-[r:DEFINES]->(a) RETURN r;
  # MATCH (a:Element {elementName: ",parameters$defEle,"}), (b:Definition {defUUID:",parameters$defUUID,"})
  # CREATE (a)-[r:DEFINED_AS]->(b) RETURN r;", sep = "")
  # 
  # 
  # 
  #       }
  #    
  #     }
  #     if (counterDef$n == 0) {
  #       downloadStore$def_list <- paste(" ")
  #       output$def_list <-  renderText(paste( " "))
  #     }
  #   })
  # 
  #   #Store number of input boxes
  #   output$counterDef <- renderPrint(print(counterDef$n))
  # 
  #   #code to generate input boxes
  #   defboxes <- reactive({
  # 
  #     n <- counterDef$n
  # 
  #     if (n > 0) {
  #       # If the no. of boxes previously where more than zero, then
  #       #save the inputs in those boxes
  #       if(prevcountDef$n > 0){
  # 
  # #       dName = c()
  #         dFull = c()
  #         dEle = c()
  # 
  #         if(prevcountDef$n > n){
  #           lesscnt <- n
  #           isInc <- FALSE
  #         }else{
  #           lesscnt <- prevcountDef$n
  #           isInc <- TRUE
  #         }
  #         for(i in 1:lesscnt){
  # #         inpDefName = paste0("defName",i)
  # #         dName[i] = input[[inpDefName]]
  #           inpDefFull = paste0("defFull",i)
  #           dFull[i]=input[[inpDefFull]]
  #           inpDefEle = paste0("defEle",i)
  #           dEle[i] = input[[inpDefEle]]
  # 
  # 
  #         }
  #         if(isInc){
  # #         dName <- c(dName, "Definition Name")
  #           dFull <- c(dFull, input[[paste0("defFull",n)]])
  #           dEle <- c(dEle, input[[paste0("defEle",n)]])
  # #          dEle <- c(dEle, "Element Name")
  #         }
  # 
  #         lapply(seq_len(n), function(i) {
  #           elementInputs<- tagList(
  # #          textInput(inputId = paste0("defName", i),
  # #                    label = paste0("Definition ", i), value = dName[i]),
  #           selectInput(inputId = paste0("defEle", i),
  #                       label = paste0("What element does Definition ", i," define?"),
  #                       parameters$elementName_select, selected = dEle[i]),
  #             textInput(inputId = paste0("defFull", i),
  #                       label = paste0("What is its definition?"), value = dFull[i])
  # 
  #           )})
  # 
  #       }else{
  #         lapply(seq_len(n), function(i) {
  #           elementInputs<- tagList(
  # #           textInput(inputId = paste0("defName", i),
  # #                      label = paste0("Definition ", i), value = "Definition Name"),
  #           selectInput(inputId = paste0("defEle", i),
  #                       label = paste0("What element does Definition ", i," define?"),
  #                       parameters$elementName_select),
  #           textInput(inputId = paste0("defFull", i),
  #                       label = paste0("What is its definition?"), value = "Definition")
  # 
  #           )})
  #       }
  # 
  #     }
  # 
  #   })
  # 
  # 
  # 
  #   #display input boxes
  #   output$def_ui <- renderUI({ defboxes() })
  
  
  
  
  
  ###################################################################
  
  
  
  # Track the number of  input boxes to render
  counterModels <- reactiveValues(n = 0)
  
  #Track the number of input boxes previously
  prevcountModels <-reactiveValues(n = 0)
  
  #On click: add input box
  observeEvent(input$model_add_btn, {
    counterModels$n <- counterModels$n + 1
    prevcountModels$n <- counterModels$n - 1})
  
  #On click: remove last  input box
  observeEvent(input$model_rm_btn, {
    if (counterModels$n > 0) {
      counterModels$n <- counterModels$n - 1
      prevcountModels$n <- counterModels$n + 1
    }
    
  })
  
  
  
  #On click: store values from input boxes in a list within parameters list
  observeEvent(input$model_save_btn, {
    if (counterModels$n > 0) {
      parameters$modelTitle <- NA
      parameters$modelType <- NA
      parameters$modelUUID <- NA
      
      for(i in 1:counterModels$n) {
        
        parameters$modelTitle[i] <- to_null(input[[paste0("modelTitle",i)]])
        parameters$modelTitle_select[i] <- input[[paste0("modelTitle",i)]]
        parameters$modelUUID[i] <- to_null(UUIDgenerate(FALSE, 1))
        parameters$modelType[i] <- to_null(input[[paste0("modelType", i)]])
        
      }
      if(input$pubTyp == "Manual Pub"){
        output$model_list <- renderText(paste("CREATE (m:Model {modelTitle: ",parameters$modelTitle,", modelUUID: ",parameters$modelUUID,", modelType: ",parameters$modelType,"});",
                                              "MATCH (p:Publication {pubUUID: '",parameters$pubUUID,"'}),(m:Model {modelUUID:",parameters$modelUUID,"})
                                             CREATE (p)-[r:CONTAINS]->(m)
                                             RETURN r;"
                                              , sep = ""))
        
        downloadStore$model_list <- paste("CREATE (m:Model {modelTitle: ",parameters$modelTitle,", modelUUID: ",parameters$modelUUID,", modelType: ",parameters$modelType,"});",
                                          "MATCH (p:Publication {pubUUID: '",parameters$pubUUID,"'}),(m:Model {modelUUID:",parameters$modelUUID,"})
                                             CREATE (p)-[r:CONTAINS]->(m)
                                             RETURN r;"
                                          , sep = "")
      }
      else{
        output$model_list <- renderText(paste("CREATE (m:Model {modelTitle: ",parameters$modelTitle,", modelUUID: ",parameters$modelUUID,", modelType: ",parameters$modelType,"});",
                                              "MATCH (p:Publication {DOI: ",parameters$doi,"}),(m:Model {modelUUID:",parameters$modelUUID,"})
                                              CREATE (p)-[r:CONTAINS]->(m)
                                              RETURN r;"
                                              , sep = ""))
        
        downloadStore$model_list <- paste("CREATE (m:Model {modelTitle: ",parameters$modelTitle,", modelUUID: ",parameters$modelUUID,", modelType: ",parameters$modelType,"});",
                                          "MATCH (p:Publication {DOI: ",parameters$doi,"}),(m:Model {modelUUID:",parameters$modelUUID,"})
                                              CREATE (p)-[r:CONTAINS]->(m)
                                              RETURN r;"
                                          , sep = "")
      }
    }
    if (counterModels$n == 0) {
      downloadStore$model_list <- paste(" ")
      output$model_list <-  renderText(paste( " "))
    }
  })
  
  #Store number of model input boxes
  output$counterModels <- renderPrint(print(counterModels$n))
  
  #code to generate model input boxes
  modelBoxes <- reactive({
    
    n <- counterModels$n
    
    if (n > 0) {
      # If the no. of model boxes previously were more than zero, then
      #save the text inputs in those text boxes
      if(prevcountModels$n > 0){
        
        grTitle = c()
        grType = c()
        
        if(prevcountModels$n > n){
          lesscnt <- n
          isInc <- FALSE
        }else{
          lesscnt <- prevcountModels$n
          isInc <- TRUE
        }
        for(i in 1:lesscnt){
          inpTit = paste0("modelTitle",i)
          grTitle[i] = input[[inpTit]]
          inpTyp = paste0("modelType", i)
          grType[i] = input[[inpTyp]]
        }
        if(isInc){
          grTitle <- c(grTitle, input[[paste0("modelTitle",n)]])
          grType <- c(grType, input[[paste0("modelType", n)]])
        }
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            textInput(inputId = paste0("modelTitle", i),
                      label = paste0("What is the name of this research model?"), value = grTitle[i]),
            selectInput(inputId = paste0("modelType",i),
                        label = paste0("Please choose the research model type?"),
                        c("Causal" = "Causal", "Correlational" = "Correlational", "Process" = "Process", "Hybrid" = "Hybrid"), 
                        #parameters$elementName_select,
                        selected = grType[i]))
          
        })
        
      }else{
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            textInput(inputId = paste0("modelTitle", i),
                      label = paste0("What is the name of this research model?"), value = "New Model"),
            #numericInput(inputId = paste0("modelLength", i),
            #          label = paste0("How many elements are in Model ", i," ?"), value = 0),
            #modelSelectMaker(input[[paste0("modelLength",i)]],parameters$elementName,i))
            selectInput(inputId = paste0("modelType",i),
                        label = "Please choose the research model type?",
                        c("Causal" = "Causal", "Correlational" = "Correlational", "Process" = "Process", "Hybrid" = "Hybrid")))
          
        })
      }
      
    }
    
  })
  
  
  
  #display model input boxes
  output$model_ui <- renderUI({ modelBoxes() })
  
  ###########################################################################
  # Track the number of input boxes to render
  counterRelate <- reactiveValues(n = 0)
  
  #Track the number of input boxes previously
  prevcountRelate <-reactiveValues(n = 0)
  
  #On click: add  input box
  observeEvent(input$rel_add_btn, {
    counterRelate$n <- counterRelate$n + 1
    prevcountRelate$n <- counterRelate$n - 1})
  
  #On click: remove last input box
  observeEvent(input$rel_rm_btn, {
    if (counterRelate$n > 0) {
      counterRelate$n <- counterRelate$n - 1
      prevcountRelate$n <- counterRelate$n + 1
    }
    parameters$grOrig <- parameters$grOrig[-max(NROW(parameters$grOrig))]
  })
  
  #On click: store values from input boxes in a list within parameters list
  observeEvent(input$rel_save_btn, {
    if (counterRelate$n > 0) {
      parameters$ele1 <- NA
      parameters$ele2 <- NA
      #parameters$ele3 <- NA
      parameters$relTyp <- NA
      parameters$grOrig <- NA
      parameters$relUUID <- NA
      parameters$modelCnt <- NA
      parameters$modid <- NA
      #modelcount <- c()
      for(i in 1:counterRelate$n) {
        parameters$ele1[i] <- to_null(input[[paste0("ele1",i)]])
        parameters$ele2[i] <- to_null(input[[paste0("ele2",i)]])
        parameters$desc[i] <- to_null(input[[paste0("desc",i)]])
        parameters$relTyp[i] <- to_null(input[[paste0("relTyp", i)]])
        parameters$grOrig[i] <- input[[paste0("grOrig",i)]]
        parameters$relUUID[i] <- UUIDgenerate(FALSE, 1)
        parameters$modid[i] <- parameters$modelUUID[which(parameters$modelTitle_select == input[[paste0("grOrig",i)]])]
        parameters$modelCnt[i] <- length(which(parameters$grOrig == input[[paste0("grOrig",i)]]))
      }
      
      output$rel_list <-  renderText(paste("CREATE (:Relation {number: '", parameters$modelCnt,"', uuid: '",parameters$relUUID,"', type: ",parameters$relTyp,"});
      
      MATCH (a:Element {elementName: ",parameters$ele1," }), (c:Relation {uuid: '",parameters$relUUID, "'})
      CREATE (c)-[r:HAS{role: 'antecedent' }]->(a)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele2,"}), (c:Relation {uuid: '" ,parameters$relUUID ,"'})
      CREATE (c)-[r:HAS{role: 'consequent'}]->(b)
      RETURN r;
      
      MATCH (m:Model {modelUUID: ", parameters$modid,"}), (c:Relation {number: '",parameters$modelCnt ,"',uuid: '", parameters$relUUID,"', type:",parameters$relTyp,"})
      CREATE (m)-[r:DEPICTS]->(c)
      RETURN r;", sep = ""))
      
      
      
      downloadStore$rel_list <- paste("CREATE (:Relation {number: '", parameters$modelCnt,"', uuid: '",parameters$relUUID,"', type: ",parameters$relTyp,"});
      
      MATCH (a:Element {elementName: ",parameters$ele1," }), (c:Relation {uuid: '",parameters$relUUID, "'})
      CREATE (c)-[r:HAS{role: 'antecedent' }]->(a)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele2,"}), (c:Relation {uuid: '" ,parameters$relUUID ,"'})
      CREATE (c)-[r:HAS{role: 'consequent'}]->(b)
      RETURN r;
      
      MATCH (m:Model {modelUUID: ", parameters$modid,"}), (c:Relation {number: '",parameters$modelCnt ,"',uuid: '", parameters$relUUID,"', type:",parameters$relTyp,"})
      CREATE (m)-[r:DEPICTS]->(c)
      RETURN r;", sep = "")
      
    }
    if (counterRelate$n == 0) {
      downloadStore$rel_list <- paste(" ")
      output$rel_list <-  renderText(paste(" "))
    }
  })
  
  #Store number of input boxes
  output$counterRelate <- renderPrint(print(counterRelate$n))
  
  #code to generate input boxes
  #code to generate input boxes
  relBoxes <- reactive({
    
    n <- counterRelate$n
    
    if (n > 0) {
      # If the no. of boxes previously where more than zero, then
      #save the inputs in those boxes
      if(prevcountRelate$n > 0){
        
        el1 = c()
        el2 = c()
        descri = c()
        rel_Typ = c()
        gr_Orig = c()
        
        if(prevcountRelate$n > n){
          lesscnt <- n
          isInc <- FALSE
        }else{
          lesscnt <- prevcountRelate$n
          isInc <- TRUE
        }
        for(i in 1:lesscnt){
          inpele1 = paste0("ele1",i)
          el1[i] = input[[inpele1]]
          inpele2 = paste0("ele2",i)
          el2[i]=input[[inpele2]]
          inpdesc = paste0("desc",i)
          descri[i] = input[[inpdesc]]
          inprelTyp = paste0("relTyp",i)
          rel_Typ[i] = input[[inprelTyp]]
          inpgrOrig = paste0("grOrig",i)
          gr_Orig[i] = input[[inpgrOrig]]
          
        }
        if(isInc){
          el1 <- c(el1, input[[paste0("ele1",n)]])
          el2 <- c(el2, input[[paste0("el2",n)]])
          descri <- c(descri, input[[paste0("desc",n)]])
          rel_Typ <- c(rel_Typ, input[[paste0("relTyp",n)]])
          gr_Orig <- c(gr_Orig, input[[paste0("grOrig",n)]])
        }
        
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            selectInput(inputId = paste0("ele1",i),
                        label = paste0("What is the antecedent of this relationship?"), parameters$elementName_select,selected = el1[i]),
            selectInput(inputId = paste0("ele2",i), label = "What is the consequent of this relationship?", parameters$elementName_select,selected = el2[i]),
            textInput(inputId = paste0("desc", i),  label = "Description of the relationship (if applicable)", value = descri[i]),
            selectInput(inputId = paste0("relTyp",i), label = paste0("What type of relationship is this?"),
                        c("Causal" = "Causal","Correlational" = "Correlational"), selected = rel_Typ[i]),
            selectInput(inputId = paste0("grOrig",i), label = "Which model includes this relationship?", parameters$modelTitle_select,
                        selected = gr_Orig[i])
          )
        })
        
        
      }else{
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            selectInput(inputId = paste0("ele1",i), label = paste0("What is the antecedent of this relationship?"), parameters$elementName_select),
            selectInput(inputId = paste0("ele2",i), label = "What is the consequent of this relationship?", parameters$elementName_select),
            textInput(inputId = paste0("desc", i), label = "Description of the relationship (if applicable)", value = ""),
            selectInput(inputId = paste0("relTyp",i), label = paste0("What type of relationship is this?"),
                        c("Causal" = "Causal", "Correlational" = "Correlational")),
            selectInput(inputId = paste0("grOrig",i), label = "Which model includes this relationship?", parameters$modelTitle_select)
          )
        })
        
      }
      
    }
  })
  
  #display input boxes
  output$rel_ui <- renderUI({ relBoxes() })
  
  #########################################################  
  #Initialize modelcount at 0
  #modelCnt <- reactiveValues(i = 0)
  # Track the number of input boxes to render
  counterRelateP <- reactiveValues(n = 0)
  
  #Track the number of input boxes previously
  prevcountRelateP <-reactiveValues(n = 0)
  
  #On click: add  input box
  observeEvent(input$rel_add_btn2, {
    counterRelateP$n <- counterRelateP$n + 1
    prevcountRelateP$n <- counterRelateP$n - 1})
  
  #On click: remove last input box
  observeEvent(input$rel_rm_btn2, {
    if (counterRelateP$n > 0) {
      counterRelateP$n <- counterRelateP$n - 1
      prevcountRelateP$n <- counterRelateP$n + 1
      
    }
    parameters$grOrigP <- parameters$grOrigP[-max(NROW(parameters$grOrigP))]
  })
  
  #On click: store values from input boxes in a list within parameters list
  observeEvent(input$rel_save_btn2, {
    if (counterRelateP$n > 0) {
      parameters$ele1P <- NA
      parameters$ele2P <- NA
      #parameters$descM <- NA
      #parameters$relTypP <- NA
      parameters$grOrigP <- NA
      parameters$relUUIDP <- NA
      parameters$modidP <- NA
      parameters$modelCntP <- NA
      for(i in 1:counterRelateP$n) {
        parameters$ele1P[i] <- to_null(input[[paste0("ele1P",i)]])
        parameters$ele2P[i] <- to_null(input[[paste0("ele2P",i)]])
        parameters$descP[i] <- to_null(input[[paste0("descP",i)]])
        #parameters$relTypP[i] <- to_null(input[[paste0("relTypP", i)]])
        parameters$grOrigP[i] <- input[[paste0("grOrigP",i)]]
        parameters$relUUIDP[i] <- UUIDgenerate(FALSE, 1)
        parameters$modidP[i] <- parameters$modelUUID[which(parameters$modelTitle_select == input[[paste0("grOrigP",i)]])]
        parameters$modelCntP[i] <- length(which(parameters$grOrig == input[[paste0("grOrigP",i)]])) + length(which(parameters$grOrigP == input[[paste0("grOrigP",i)]]))
      }
      #   output$rel_list <- renderText(paste("<b>MATCH (a:Element {elementName: ",parameters$ele1,"}),(b:Element {elementName: ",parameters$ele2,"})
      # <br>CREATE (a)-[r:RELATES_TO {description:",parameters$desc,", type: '",parameters$relTyp,"', model: '",parameters$grOrig,"'}]->(b)
      # <br>RETURN r;</b>","<br/><br/>", sep = ""))
      
      output$rel_list2 <-  renderText(paste("CREATE (:Relation {number: '", parameters$modelCntP ,"', uuid: '",parameters$relUUIDP,"', type:  'Process'});
      
      MATCH (a:Element {elementName: ",parameters$ele1P," }), (c:Relation {uuid: '",parameters$relUUIDP, "'})
      CREATE (c)-[r:HAS{role: 'antecedent' }]->(a)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele2P,"}), (c:Relation {uuid: '" ,parameters$relUUIDP ,"'})
      CREATE (c)-[r:HAS{role: 'consequent'}]->(b)
      RETURN r;
      
      MATCH (m:Model {modelUUID: ", parameters$modidP,"}), (c:Relation {number: '",parameters$modelCntP ,"',uuid: '", parameters$relUUIDP,"', type: 'Process'})
      CREATE (m)-[r:DEPICTS]->(c)
      RETURN r;", sep = ""))
      
      
      
      downloadStore$rel_list2 <- paste("CREATE (:Relation {number: '", parameters$modelCntP ,"', uuid: '",parameters$relUUIDP,"', type:  'Process'});
      
      <MATCH (a:Element {elementName: ",parameters$ele1P," }), (c:Relation {uuid: '",parameters$relUUIDP, "'})
      CREATE (c)-[r:HAS{role: 'antecedent' }]->(a)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele2P,"}), (c:Relation {uuid: '" ,parameters$relUUIDP ,"'})
      CREATE (c)-[r:HAS{role: 'consequent'}]->(b)
      RETURN r;
      
      MATCH (m:Model {modelUUID: ", parameters$modidP,"}), (c:Relation {number: '",parameters$modelCntP ,"',uuid: '", parameters$relUUIDP,"', type: 'Process'})
      CREATE (m)-[r:DEPICTS]->(c)
      RETURN r;", sep = "")
      
      
      #       downloadStore$rel_list <- paste("MATCH (a:Element {elementName: ",parameters$ele1,"}),(b:Element {elementName: ",parameters$ele2,"})
      # CREATE (a)-[r:RELATES_TO {description:",parameters$desc,", type: '",parameters$relTyp,"', model: '",parameters$grOrig,"'}]->(b)
      # RETURN r;", sep = "")
    }
    if (counterRelateP$n == 0) {
      downloadStore$rel_list2 <- paste(" ")
      output$rel_list2 <-  renderText(paste( " "))
    }
  })
  
  #Store number of input boxes
  output$counterRelateP <- renderPrint(print(counterRelateP$n))
  
  #code to generate input boxes
  #code to generate input boxes
  relBoxes2 <- reactive({
    
    n <- counterRelateP$n
    
    if (n > 0) {
      # If the no. of boxes previously where more than zero, then
      #save the inputs in those boxes
      if(prevcountRelateP$n > 0){
        
        el1P = c()
        el2P = c()
        descriP = c()
        #rel_TypP = c()
        gr_OrigP = c()
        
        if(prevcountRelateP$n > n){
          lesscntP <- n
          isIncP <- FALSE
        }else{
          lesscntP <- prevcountRelateP$n
          isIncP <- TRUE
        }
        for(i in 1:lesscntP){
          inpele1P = paste0("ele1P",i)
          el1P[i] = input[[inpele1P]]
          inpele2P = paste0("ele2P",i)
          el2P[i]=input[[inpele2P]]
          inpdescP = paste0("descP",i)
          descriP[i] = input[[inpdescP]]
          # inprelTypP = paste0("relTypP",i)
          # rel_TypP[i] = input[[inprelTypP]]
          inpgrOrigP = paste0("grOrigP",i)
          gr_OrigP[i] = input[[inpgrOrigP]]
          
        }
        if(isIncP){
          el1P <- c(el1P, input[[paste0("ele1P",n)]])
          el2P <- c(el2P, input[[paste0("ele2P",n)]])
          descriP <- c(descriP, input[[paste0("descP",n)]])
          #rel_TypP <- c(rel_TypP, input[[paste0("relTypP",n)]])
          gr_OrigP <- c(gr_OrigP, input[[paste0("grOrigP",n)]])
        }
        
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            selectInput(inputId = paste0("ele1P",i),
                        label = paste0("What is first event?"), parameters$elementName_select,selected = el1P[i]),
            selectInput(inputId = paste0("ele2P",i), label = "What is second event?", parameters$elementName_select,selected = el2P[i]),
            textInput(inputId = paste0("descP", i),  label = "Description of the relationship (if applicable)", value = descriP[i]),
            #selectInput(inputId = paste0("relTypP",i), label = paste0("What type of relationship is this?"),
            #        c("Causal" = "Causal","Correlational" = "Correlational"), selected = rel_Typ[i]),
            selectInput(inputId = paste0("grOrigP",i), label = "Which model includes this relationship?", parameters$modelTitle_select,
                        selected = gr_OrigP[i])
          )
        })
        
        
      }else{
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            selectInput(inputId = paste0("ele1P",i), label = paste0("What is first event?"), parameters$elementName_select),
            selectInput(inputId = paste0("ele2P",i), label = "What is second event?", parameters$elementName_select),
            textInput(inputId = paste0("descP", i), label = "Description of the relationship (if applicable)", value = ""),
            # selectInput(inputId = paste0("relTyp",i), label = paste0("What type of relationship is this?"),
            #             c("Causal" = "Causal", "Correlational" = "Correlational")),
            selectInput(inputId = paste0("grOrigP",i), label = "Which model includes this relationship?", parameters$modelTitle_select)
          )
        })
        
      }
      
    }
  })
  
  
  #display input boxes
  output$rel_ui2 <- renderUI({ relBoxes2() })  
  
  
  
  
  
  #########################################################  
  # Track the number of input boxes to render
  counterRelateM <- reactiveValues(n = 0)
  
  #Track the number of input boxes previously
  prevcountRelateM <-reactiveValues(n = 0)
  
  #On click: add  input box
  observeEvent(input$rel_add_btn3, {
    counterRelateM$n <- counterRelateM$n + 1
    prevcountRelateM$n <- counterRelateM$n - 1
    
  })
  
  #On click: remove last input box
  observeEvent(input$rel_rm_btn3, {
    if (counterRelateM$n > 0) {
      counterRelateM$n <- counterRelateM$n - 1
      prevcountRelateM$n <- counterRelateM$n + 1
    }
    parameters$grOrigM <- parameters$grOrigM[-max(NROW(parameters$grOrigM))]
  })
  
  #On click: store values from input boxes in a list within parameters list
  observeEvent(input$rel_save_btn3, {
    if (counterRelateM$n > 0) {
      parameters$ele1M <- NA
      parameters$ele2M <- NA
      parameters$ele3M <- NA
      #parameters$descM <- NA
      #parameters$relTypP <- NA
      parameters$grOrigM <- NA
      parameters$relUUIDM <- NA
      parameters$modidM <- NA
      parameters$modelCntM <- NA
      for(i in 1:counterRelateM$n) {
        parameters$ele1M[i] <- to_null(input[[paste0("ele1M",i)]])
        parameters$ele2M[i] <- to_null(input[[paste0("ele2M",i)]])
        parameters$ele3M[i] <- to_null(input[[paste0("ele3M",i)]])
        parameters$descM[i] <- to_null(input[[paste0("descM",i)]])
        #parameters$relTypP[i] <- to_null(input[[paste0("relTypP", i)]])
        parameters$grOrigM[i] <- input[[paste0("grOrigM",i)]]
        parameters$relUUIDM[i] <- UUIDgenerate(FALSE, 1)
        parameters$modidM[i] <- parameters$modelUUID[which(parameters$modelTitle_select == input[[paste0("grOrigM",i)]])]
        parameters$modelCntM[i] <- length(which(parameters$grOrig == input[[paste0("grOrigM",i)]])) + length(which(parameters$grOrigP == input[[paste0("grOrigM",i)]])) + length(which(parameters$grOrigM == input[[paste0("grOrigM",i)]]))
      }
      #   output$rel_list <- renderText(paste("<b>MATCH (a:Element {elementName: ",parameters$ele1,"}),(b:Element {elementName: ",parameters$ele2,"})
      # <br>CREATE (a)-[r:RELATES_TO {description:",parameters$desc,", type: '",parameters$relTyp,"', model: '",parameters$grOrig,"'}]->(b)
      # <br>RETURN r;</b>","<br/><br/>", sep = ""))
      
      output$rel_list3 <-  renderText(paste("CREATE (:Relation {number: '", parameters$modelCntM ,"', uuid: '",parameters$relUUIDM,"', type:  'Mediating'});
      
      MATCH (a:Element {elementName: ",parameters$ele1M," }), (c:Relation {uuid: '",parameters$relUUIDM, "'})
      CREATE (c)-[r:HAS{role: 'antecedent' }]->(a)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele2M,"}), (c:Relation {uuid: '" ,parameters$relUUIDM ,"'})
      CREATE (c)-[r:HAS{role: 'consequent'}]->(b)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele3M,"}), (c:Relation {uuid: '" ,parameters$relUUIDM ,"'})
      CREATE (c)-[r:HAS{role: 'mediator'}]->(b)
      RETURN r;
      
      MATCH (m:Model {modelUUID: ", parameters$modidM,"}), (c:Relation {number: '",parameters$modelCntM ,"',uuid: '", parameters$relUUIDM,"', type: 'Mediating'})
      CREATE (m)-[r:DEPICTS]->(c)
      RETURN r;", sep = ""))
      
      
      
      downloadStore$rel_list3 <- paste("CREATE (:Relation {number: '", parameters$modelCntM ,"', uuid: '",parameters$relUUIDM,"', type:  'Mediating'});
      
      MATCH (a:Element {elementName: ",parameters$ele1M," }), (c:Relation {uuid: '",parameters$relUUIDM, "'})
      CREATE (c)-[r:HAS{role: 'antecedent' }]->(a)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele2M,"}), (c:Relation {uuid: '" ,parameters$relUUIDM ,"'})
      CREATE (c)-[r:HAS{role: 'consequent'}]->(b)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele3M,"}), (c:Relation {uuid: '" ,parameters$relUUIDM ,"'})
      CREATE (c)-[r:HAS{role: 'mediator'}]->(b)
      RETURN r;
      
      MATCH (m:Model {modelUUID: ", parameters$modidM,"}), (c:Relation {number: '",parameters$modelCntM ,"',uuid: '", parameters$relUUIDM,"', type: 'Mediating'})
      CREATE (m)-[r:DEPICTS]->(c)
      RETURN r;", sep = "")
    }
    if (counterRelateM$n == 0) {
      downloadStore$rel_list3 <- paste(" ")
      output$rel_list3 <-  renderText(paste( " "))
    }
  })
  
  #Store number of input boxes
  output$counterRelateM <- renderPrint(print(counterRelateM$n))
  
  #code to generate input boxes
  #code to generate input boxes
  relBoxes3 <- reactive({
    
    n <- counterRelateM$n
    
    if (n > 0) {
      # If the no. of boxes previously where more than zero, then
      #save the inputs in those boxes
      if(prevcountRelateM$n > 0){
        
        el1M = c()
        el2M = c()
        el3M = c()
        descriM = c()
        #rel_TypP = c()
        gr_OrigM = c()
        
        if(prevcountRelateM$n > n){
          lesscntM <- n
          isIncM <- FALSE
        }else{
          lesscntM <- prevcountRelateM$n
          isIncM <- TRUE
        }
        for(i in 1:lesscntM){
          inpele1M = paste0("ele1M",i)
          el1M[i] = input[[inpele1M]]
          inpele2M = paste0("ele2M",i)
          el2M[i] = input[[inpele2M]]
          inpele3M = paste0("ele3M",i)
          el3M[i] = input[[inpele3M]]
          inpdescM = paste0("descM",i)
          descriM[i] = input[[inpdescM]]
          # inprelTypP = paste0("relTypP",i)
          # rel_TypP[i] = input[[inprelTypP]]
          inpgrOrigM = paste0("grOrigM",i)
          gr_OrigM[i] = input[[inpgrOrigM]]
          
        }
        if(isIncM){
          el1M <- c(el1M, input[[paste0("ele1M",n)]])
          el2M <- c(el2M, input[[paste0("ele2M",n)]])
          el3M <- c(el3M, input[[paste0("ele3M",n)]])
          descriM <- c(descriM, input[[paste0("descM",n)]])
          #rel_TypP <- c(rel_TypP, input[[paste0("relTypP",n)]])
          gr_OrigM <- c(gr_OrigM, input[[paste0("grOrigM",n)]])
        }
        
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            selectInput(inputId = paste0("ele1M",i),
                        label = paste0("What is the antecedent of the relationship?"), parameters$elementName_select,selected = el1M[i]),
            selectInput(inputId = paste0("ele2M",i), label = paste0("What is the consequent of the relationship?"), parameters$elementName_select,selected = el2M[i]),
            selectInput(inputId = paste0("ele3M",i), label = paste0("What is the mediator of the relationship?"), parameters$elementName_select,selected = el3M[i]),
            textInput(inputId = paste0("descM", i),  label = "Description of the relationship (if applicable)", value = descriM[i]),
            #selectInput(inputId = paste0("relTypP",i), label = paste0("What type of relationship is this?"),
            #        c("Causal" = "Causal","Correlational" = "Correlational"), selected = rel_Typ[i]),
            selectInput(inputId = paste0("grOrigM",i), label = "Which model includes this relationship?", parameters$modelTitle_select,
                        selected = gr_OrigM[i])
          )
        })
        
        
      }else{
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            selectInput(inputId = paste0("ele1M",i), label = paste0("What is the antecedent of the relationship?"), parameters$elementName_select),
            selectInput(inputId = paste0("ele2M",i), label = "What is the consequent of the relationship?", parameters$elementName_select),
            selectInput(inputId = paste0("ele3M",i), label = "What is the mediator of the relationship?", parameters$elementName_select),
            textInput(inputId = paste0("descM", i), label = "Description of the relationship (if applicable)", value = ""),
            # selectInput(inputId = paste0("relTyp",i), label = paste0("What type of relationship is this?"),
            #             c("Causal" = "Causal", "Correlational" = "Correlational")),
            selectInput(inputId = paste0("grOrigM",i), label = "Which model includes this relationship?", parameters$modelTitle_select)
          )
        })
        
      }
      
    }
  })
  
  
  #display input boxes
  output$rel_ui3 <- renderUI({ relBoxes3() })
  
  
  
  #########################################################  
  # Track the number of input boxes to render
  counterRelateN <- reactiveValues(n = 0)
  
  #Track the number of input boxes previously
  prevcountRelateN <-reactiveValues(n = 0)
  
  #On click: add  input box
  observeEvent(input$rel_add_btn4, {
    counterRelateN$n <- counterRelateN$n + 1
    prevcountRelateN$n <- counterRelateN$n - 1})
  
  #On click: remove last input box
  observeEvent(input$rel_rm_btn4, {
    if (counterRelateN$n > 0) {
      counterRelateN$n <- counterRelateN$n - 1
      prevcountRelateN$n <- counterRelateN$n + 1
      
    }
    parameters$grOrigN <- parameters$grOrigN[-max(NROW(parameters$grOrigN))]
  })
  
  #On click: store values from input boxes in a list within parameters list
  observeEvent(input$rel_save_btn4, {
    if (counterRelateN$n > 0) {
      parameters$ele1N <- NA
      parameters$ele2N <- NA
      parameters$ele3N <- NA
      parameters$descN <- NA
      #parameters$relTypP <- NA
      parameters$grOrigN <- NA
      parameters$relUUIDN <- NA
      parameters$modidN <- NA
      parameters$modelCntN <- NA
      for(i in 1:counterRelateN$n) {
        parameters$ele1N[i] <- to_null(input[[paste0("ele1N",i)]])
        parameters$ele2N[i] <- to_null(input[[paste0("ele2N",i)]])
        parameters$ele3N[i] <- to_null(input[[paste0("ele3N",i)]])
        parameters$descN[i] <- to_null(input[[paste0("descN",i)]])
        #parameters$relTypP[i] <- to_null(input[[paste0("relTypP", i)]])
        parameters$grOrigN[i] <- input[[paste0("grOrigN",i)]]
        parameters$relUUIDN[i] <- UUIDgenerate(FALSE, 1)
        parameters$modidN[i] <- parameters$modelUUID[which(parameters$modelTitle_select == input[[paste0("grOrigN",i)]])]
        parameters$modelCntN[i] <- length(which(parameters$grOrig == input[[paste0("grOrigN",i)]])) + length(which(parameters$grOrigP == input[[paste0("grOrigN",i)]])) + length(which(parameters$grOrigM == input[[paste0("grOrigN",i)]])) + length(which(parameters$grOrigN == input[[paste0("grOrigN",i)]]))
      }
      
      output$rel_list4 <-  renderText(paste("CREATE (:Relation {number: '", parameters$modelCntN ,"', uuid: '",parameters$relUUIDN,"', type:  'Moderating'});
      
      MATCH (a:Element {elementName: ",parameters$ele1N," }), (c:Relation {uuid: '",parameters$relUUIDN, "'})
      CREATE (c)-[r:HAS{role: 'antecedent' }]->(a)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele2N,"}), (c:Relation {uuid: '" ,parameters$relUUIDN ,"'})
      CREATE (c)-[r:HAS{role: 'consequent'}]->(b)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele3N,"}), (c:Relation {uuid: '" ,parameters$relUUIDN ,"'})
      CREATE (c)-[r:HAS{role: 'mediator'}]->(b)
      RETURN r;
      
      MATCH (m:Model {modelUUID: ", parameters$modidN,"}), (c:Relation {number: '",parameters$modelCntN ,"',uuid: '", parameters$relUUIDN,"', type: 'Moderating'})
      CREATE (m)-[r:DEPICTS]->(c)
      RETURN r;", sep = ""))
      
      
      
      downloadStore$rel_list4 <- paste("CREATE (:Relation {number: '", parameters$modelCntN ,"', uuid: '",parameters$relUUIDN,"', type:  'Moderating'});
      
      MATCH (a:Element {elementName: ",parameters$ele1N," }), (c:Relation {uuid: '",parameters$relUUIDN, "'})
      CREATE (c)-[r:HAS{role: 'antecedent' }]->(a)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele2N,"}), (c:Relation {uuid: '" ,parameters$relUUIDN ,"'})
      CREATE (c)-[r:HAS{role: 'consequent'}]->(b)
      RETURN r;
      
      MATCH (b:Element {elementName: ",parameters$ele3N,"}), (c:Relation {uuid: '" ,parameters$relUUIDN ,"'})
      CREATE (c)-[r:HAS{role: 'mediator'}]->(b)
      RETURN r;
      
      MATCH (m:Model {modelUUID: ", parameters$modidN,"}), (c:Relation {number: '",parameters$modelCntN ,"',uuid: '", parameters$relUUIDN,"', type: 'Moderating'})
      CREATE (m)-[r:DEPICTS]->(c)
      RETURN r;", sep = "")
    }
    if (counterRelateN$n == 0) {
      downloadStore$rel_list4 <- paste(" ")
      output$rel_list4 <-  renderText(paste( " "))
    }
  })
  
  #Store number of input boxes
  output$counterRelateN <- renderPrint(print(counterRelateN$n))
  
  #code to generate input boxes
  #code to generate input boxes
  relBoxes4 <- reactive({
    
    n <- counterRelateN$n
    
    if (n > 0) {
      # If the no. of boxes previously where more than zero, then
      #save the inputs in those boxes
      if(prevcountRelateN$n > 0){
        
        el1N = c()
        el2N = c()
        el3N = c()
        descriN = c()
        #rel_TypP = c()
        gr_OrigN = c()
        
        if(prevcountRelateN$n > n){
          lesscntN <- n
          isIncN <- FALSE
        }else{
          lesscntN <- prevcountRelateN$n
          isIncN <- TRUE
        }
        for(i in 1:lesscntN){
          inpele1N = paste0("ele1N",i)
          el1N[i] = input[[inpele1N]]
          inpele2N = paste0("ele2N",i)
          el2N[i]=input[[inpele2N]]
          inpele3N = paste0("ele3N",i)
          el3N[i]=input[[inpele3N]]
          inpdescN = paste0("descN",i)
          descriN[i] = input[[inpdescN]]
          # inprelTypP = paste0("relTypP",i)
          # rel_TypP[i] = input[[inprelTypP]]
          inpgrOrigN = paste0("grOrigN",i)
          gr_OrigN[i] = input[[inpgrOrigN]]
          
        }
        if(isIncN){
          el1N <- c(el1N, input[[paste0("ele1N",n)]])
          el2N <- c(el2N, input[[paste0("ele2N",n)]])
          el3N <- c(el3N, input[[paste0("ele3N",n)]])
          descriN <- c(descriN, input[[paste0("descN",n)]])
          #rel_TypP <- c(rel_TypP, input[[paste0("relTypP",n)]])
          gr_OrigN <- c(gr_OrigN, input[[paste0("grOrigN",n)]])
        }
        
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            selectInput(inputId = paste0("ele1N",i),
                        label = paste0("What is the antecedent of this relationship?"), parameters$elementName_select,selected = el1N[i]),
            selectInput(inputId = paste0("ele2N",i), label = paste0("What is the consequent of this relationship?"), parameters$elementName_select,selected = el2N[i]),
            selectInput(inputId = paste0("ele3N",i), paste0("What is the moderator of this relationship?"), parameters$elementName_select,selected = el3N[i]),
            textInput(inputId = paste0("descN", i),  label = "Description of the relationship (if applicable)", value = descriN[i]),
            #selectInput(inputId = paste0("relTypP",i), label = paste0("What type of relationship is this?"),
            #        c("Causal" = "Causal","Correlational" = "Correlational"), selected = rel_Typ[i]),
            selectInput(inputId = paste0("grOrigN",i), label = "Which model includes this relationship?", parameters$modelTitle_select,
                        selected = gr_OrigN[i])
          )
        })
        
        
      }else{
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            selectInput(inputId = paste0("ele1N",i), label = paste0("What is the antecedent of this relationship?"), parameters$elementName_select),
            selectInput(inputId = paste0("ele2N",i), label = "What is the consequent of this relationship?", parameters$elementName_select),
            selectInput(inputId = paste0("ele3N",i), label = "What is the moderator of this relationship?", parameters$elementName_select),
            textInput(inputId = paste0("descN", i), label = "Description of the relationship (if applicable)", value = ""),
            # selectInput(inputId = paste0("relTyp",i), label = paste0("What type of relationship is this?"),
            #             c("Causal" = "Causal", "Correlational" = "Correlational")),
            selectInput(inputId = paste0("grOrigN",i), label = "Which model includes this relationship?", parameters$modelTitle_select)
          )
        })
        
      }
      
    }
  })
  
  
  #display input boxes
  output$rel_ui4 <- renderUI({ relBoxes4() })
  
  
  
  
  
  
  
  
  #############################################################
  observeEvent(input$pubTyp, {
    if(input$pubTyp == "DOI Pub"){
      shinyjs::hide(id = "authorBox")
      #shinyjs::hide(id = "authorBox2")
    }else{
      shinyjs::show(id = "authorBox")
      #shinyjs::show(id = "authorBox2")
    }
  })
  # Track the number of input boxes to render
  counterAuthor <- reactiveValues(n = 0)
  
  #Track the number of input boxes previously
  prevcountAuthor <-reactiveValues(n = 0)
  
  #On click: add  input box
  observeEvent(input$auth_add_btn, {
    counterAuthor$n <- counterAuthor$n + 1
    prevcountAuthor$n <- counterAuthor$n - 1})
  
  #On click: remove last input box
  observeEvent(input$auth_rm_btn, {
    if (counterAuthor$n > 0) {
      counterAuthor$n <- counterAuthor$n - 1
      prevcountAuthor$n <- counterAuthor$n + 1
    }
    
  })
  
  # On click: store values from input boxes in a list within parameters list
  
  observeEvent(input$auth_save_btn, {
    if (counterAuthor$n > 0) {
      parameters$authFirst <- NA
      parameters$authMiddle <- NA
      parameters$authLast <- NA
      parameters$orcid <- NA
      parameters$authOrder <- NA
      parameters$authUUID <- NA
      
      for(i in 1:counterAuthor$n) {
        parameters$authFirst[i] <- to_null(input[[paste0("authFirst",i)]])
        parameters$authMiddle[i] <- to_null(input[[paste0("authMiddle",i)]])
        parameters$authLast[i] <- to_null(input[[paste0("authLast",i)]])
        parameters$orcid[i] <- to_null(input[[paste0("orcid",i)]])
        parameters$authOrder[i] <- i
        parameters$authUUID[i] <- to_null(UUIDgenerate(FALSE, 1))
      }
      #if(input$pubTyp == "Manual Pub"){
      output$auth_list <- renderText(paste("CREATE (:Author {ORCID: ",parameters$orcid,", authorFirst: ",parameters$authFirst,", authorMiddle: ",parameters$authMiddle,", authorLast: ",parameters$authLast,", authUUID: ",parameters$authUUID,"});",
                                           "MATCH (p:Publication {pubUUID: '",parameters$pubUUID,"'}), (a:Author {authUUID:", parameters$authUUID,"})
                                             CREATE (p)-[r:WRITTEN_BY {authorOrder: ",parameters$authOrder,"}]->(a)
                                             RETURN r;", sep = ""))
      downloadStore$auth_list <- paste("CREATE (:Author {ORCID: ",parameters$orcid,", authorFirst: ",parameters$authFirst,", authorMiddle: ",parameters$authMiddle,", authorLast: ",parameters$authLast,", authUUID: ",parameters$authUUID,"});
MATCH (p:Publication {pubUUID: '",parameters$pubUUID,"'}), (a:Author {authUUID:", parameters$authUUID,"})
CREATE (p)-[r:WRITTEN_BY {authorOrder: ",parameters$authOrder,"}]->(a)
RETURN r;", sep = "")
      #}
      #       else{
      #         res <- cr_cn(parameters$doi_cr_cn,format = "citeproc-json", raw = F, locale = "en-US")
      #         authors <- dim(res$author)[1] 
      #         # Use loop to get each of them
      #         for(i in 1:authors) {
      #           orcid <- res$author$ORCID[i]
      #           given <-  res$author$given[i]
      #           family <- res$author$family[i]
      #         }
      #         parameters$authFirst[i] <-given
      #         #parameters$authMiddle[i] <- to_null(input[[paste0("authMiddle",i)]])
      #         parameters$authLast[i] <- family
      #         parameters$orcid[i] <- orcid
      #         parameters$authOrder[i] <- i
      #         parameters$authUUID[i] <- to_null(UUIDgenerate(FALSE, 1))
      #         output$auth_list <- renderText(paste("<b>CREATE (:Author {ORCID: ",parameters$orcid,", authorFirst: ",parameters$authFirst,", authorLast: ",parameters$authLast,", authUUID: ",parameters$authUUID,"});","<br/><br/>"
      #                                              ,"MATCH (p:Publication {DOI: ",parameters$doi,"}), (a:Author {ORCID: ",parameters$orcid,", authorFirst: ",parameters$authFirst,", authorLast: ",parameters$authLast,"})
      #                                              <br>CREATE (p)-[r:WRITTEN_BY {authorOrder: ",parameters$authOrder,"}]->(a)
      #                                              <br>RETURN r;</b>","<br/><br/>", sep = ""))
      #        downloadStore$auth_list <- paste("CREATE (:Author {ORCID: ",parameters$orcid,", authorFirst: ",parameters$authFirst,", authorLast: ",parameters$authLast,", authUUID: ",parameters$authUUID,"});
      # MATCH (p:Publication {DOI: ",parameters$doi,"}), (a:Author {authUUID:", parameters$authUUID,"})
      # CREATE (p)-[r:WRITTEN_BY {authorOrder: ",parameters$authOrder,"}]->(a)
      # RETURN r;", sep = "")
    }
  }
  )
  
  #Store number of input boxes
  output$counterAuthor <- renderPrint(print(counterAuthor$n))
  
  #code to generate input boxes
  authBoxes <- reactive({
    
    n <- counterAuthor$n
    
    if (n > 0) {
      # If the no. of boxes previously where more than zero, then
      #save the inputs in those boxes
      if(prevcountAuthor$n > 0){
        
        auth_First = c()
        auth_Middle = c()
        auth_Last = c()
        auth_Orcid = c()
        
        if(prevcountAuthor$n > n){
          lesscnt <- n
          isInc <- FALSE
        }else{
          lesscnt <- prevcountAuthor$n
          isInc <- TRUE
        }
        for(i in 1:lesscnt){
          inpAuthFirst = paste0("authFirst",i)
          auth_First[i] = input[[inpAuthFirst]]
          inpAuthMiddle = paste0("authMiddle",i)
          auth_Middle[i]=input[[inpAuthMiddle]]
          inpAuthLast = paste0("authLast",i)
          auth_Last[i] = input[[inpAuthLast]]
          inpOrcid = paste0("orcid",i)
          auth_Orcid[i]=input[[inpOrcid]]
        }
        if(isInc){
          auth_First <- c(auth_First, input[[paste0("authFirst",n)]])
          auth_Middle <- c(auth_Middle, input[[paste0("authMiddle",n)]])
          auth_Last <- c(auth_Last, input[[paste0("authLast",n)]])
          auth_Orcid <- c(auth_Orcid, input[[paste0("orcid",n)]])
        }
        
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            textInput(inputId = paste0("authFirst", i),
                      label = paste0("Author ", i,"'s First Name"), value = auth_First[i]),
            textInput(inputId = paste0("authMiddle", i),
                      label = paste0("Author ", i,"'s Middle Name/Initial (if applicable)"), value = auth_Middle[i]),
            textInput(inputId = paste0("authLast", i),
                      label = paste0("Author ", i,"'s Last Name"), value = auth_Last[i]),
            textInput(inputId = paste0("orcid", i),
                      label = paste0("Author ", i,"'s ORCID (if applicable)"), value = auth_Orcid[i]),
          )
        })
        
      }else{
        lapply(seq_len(n), function(i) {
          elementInputs <- tagList(
            textInput(inputId = paste0("authFirst", i),
                      label = paste0("Author ", i,"'s First Name"), value = ""),
            textInput(inputId = paste0("authMiddle", i),
                      label = paste0("Author ", i,"'s Middle Name/Initial (if applicable)"), value = ""),
            textInput(inputId = paste0("authLast", i),
                      label = paste0("Author ", i,"'s Last Name"), value = ""),
            textInput(inputId = paste0("orcid", i),
                      label = paste0("Author ", i,"'s ORCID (if applicable)"), value = ""),
          )
        })
      }
      
    }
    
  })
  
  
  
  #display input boxes
  output$auth_ui <- renderUI({ authBoxes() })
  
  ##########################################################################
  
  # Track the number of  input boxes to render
  counterTheory <- reactiveValues(n = 0)
  
  #Track the number of input boxes previously
  prevcountTheory <-reactiveValues(n = 0)
  
  #On click: add input box
  observeEvent(input$theo_add_btn, {
    counterTheory$n <- counterTheory$n + 1
    prevcountTheory$n <- counterTheory$n - 1})
  
  #On click: remove last input box
  observeEvent(input$theo_rm_btn, {
    if (counterTheory$n > 0) {
      counterTheory$n <- counterTheory$n - 1
      prevcountTheory$n <- counterTheory$n + 1
    }
    
  })
  
  #On click: store values from input boxes in a list within parameters list
  observeEvent(input$theo_save_btn, {
    if (counterTheory$n > 0) {
      parameters$theoName <- NA
      parameters$depict <- NA
      parameters$depictPhrase <- NA
      parameters$downloadDepictPhrase <- NA
      parameters$theoryModelUUID <- NA
      parameters$tdscrip <- NA
      b <- c()
      #parameters$theoUUID <- NA
      for(i in 1:counterTheory$n) {
        parameters$theoName[i] <- to_null(input[[paste0("theoName",i)]])
        parameters$tdscrip[i] <- to_null(input[[paste0("tdscrip",i)]])
        parameters$theoryModelUUID <- UUIDgenerate(FALSE,1 )
        b[i] <- 1
        while(b[i] <= length(input[[paste0("theoDepict",i)]])){
          if(b[i] < length(input[[paste0("theoDepict",i)]])){
            parameters$depict[i] <- paste0(na.omit(parameters$depict[i]),input[[paste0("theoDepict",i)]][b[i]],", ")
            #parameters$tdscrip[i] <- paste0(na.omit(parameters$tdscrip[i]),input[[paste0("tdscrip",i)]][b[i]],", ")
            if(input[[paste0("theoDepict",i)]][b[i]]=="Publication"){
              if(input$pubTyp == "Manual Pub"){
                parameters$depictPhrase[i] <- paste0(na.omit(parameters$depictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i], "}), (p:Publication {pubUUID: '",parameters$pubUUID,"'}) CREATE (p)-[r:DRAWS_ON]->(t) RETURN r; ")
                parameters$downloadDepictPhrase[i] <- paste0(na.omit(parameters$downloadDepictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],"}), (p:Publication {pubUUID: '",parameters$pubUUID,"'})
CREATE (p)-[r:DRAWS_ON]->(t)
RETURN r; ")
                b[i] <- b[i]+1
              }
              else{
                parameters$depictPhrase[i] <- paste0(na.omit(parameters$depictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i],  ", theoryDescription: ", parameters$tdscrip[i],"}), (p:Publication {DOI: ",parameters$doi,"}) CREATE (p)-[r:DRAWS_ON]->(t) RETURN r; ")
                parameters$downloadDepictPhrase[i] <- paste0(na.omit(parameters$downloadDepictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i],  ", theoryDescription: ", parameters$tdscrip[i],"}), (p:Publication {DOI: ",parameters$doi,"})
CREATE (p)-[r:DRAWS_ON]->(t)
RETURN r; ")
                b[i] <- b[i]+1
              }
            }
            else if(input[[paste0("theoDepict",i)]][b[i]] %in% parameters$modelTitle_select){
              for (c in 1:length(parameters$modelTitle_select)){
                if (input[[paste0("theoDepict",i)]][b[i]] == parameters$modelTitle_select[c]){
                  parameters$theoryModelUUID[i] <- parameters$modelUUID[c]
                  break
                }
              }
              parameters$depictPhrase[i] <- paste0(na.omit(parameters$depictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i],  ", theoryDescription: ", parameters$tdscrip[i],"}), (m:Model {modelUUID: ",parameters$modelUUID[i],"}) CREATE (m)-[r:APPLIES]->(t) RETURN r; ")
              parameters$downloadDepictPhrase[i] <- paste0(na.omit(parameters$downloadDepictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],"}), (m:Model {modelUUID: ",parameters$modelUUID[i],"})
CREATE (m)-[r:APPLIES]->(t)
RETURN r; ")
              b[i] <- b[i]+1
            }
            else{
              parameters$depictPhrase[i] <- paste0(na.omit(parameters$depictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],'}), (e:Element {elementName: "',input[[paste0("theoDepict",i)]][b[i]],'"}) CREATE (t)-[r:INFORMS]->(e) RETURN r; ')
              parameters$downloadDepictPhrase[i] <- paste0(na.omit(parameters$downloadDepictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],'}), (e:Element {elementName: "',input[[paste0("theoDepict",i)]][b[i]],'"})
CREATE (t)-[r:INFORMS]->(e)
RETURN r; ')
              b[i] <- b[i]+1
            }
          }else{
            parameters$depict[i] <- paste0(na.omit(parameters$depict[i]),input[[paste0("theoDepict",i)]][b[i]])
            if(input[[paste0("theoDepict",i)]][b[i]]=="Publication"){
              if(input$pubTyp == "Manual Pub"){
                parameters$depictPhrase[i] <- paste0(na.omit(parameters$depictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],"}), (p:Publication {pubUUID: '",parameters$pubUUID,"'}) CREATE (p)-[r:DRAWS_ON]->(t) RETURN r;")
                parameters$downloadDepictPhrase[i] <- paste0(na.omit(parameters$downloadDepictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],"}), (p:Publication {pubUUID: '",parameters$pubUUID,"'})
CREATE (p)-[r:DRAWS_ON]->(t)
RETURN r;")
                b[i] <- b[i]+1
              }
              else{
                parameters$depictPhrase[i] <- paste0(na.omit(parameters$depictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],"}), (p:Publication {DOI: ",parameters$doi,"}) CREATE (p)-[r:DRAWS_ON]->(t) RETURN r;")
                parameters$downloadDepictPhrase[i] <- paste0(na.omit(parameters$downloadDepictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],"}), (p:Publication {DOI: ",parameters$doi,"})
CREATE (p)-[r:DRAWS_ON]->(t)
RETURN r;")
                b[i] <- b[i]+1
              }
            }
            else if(input[[paste0("theoDepict",i)]][b[i]] %in% parameters$modelTitle_select){
              for (c in 1:length(parameters$modelTitle_select)){
                if (input[[paste0("theoDepict",i)]][b[i]] == parameters$modelTitle_select[c]){
                  parameters$theoryModelUUID[i] <- parameters$modelUUID[c]
                  break
                }
              }
              parameters$depictPhrase[i] <- paste0(na.omit(parameters$depictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],"}), (m:Model {modelUUID: '",parameters$theoryModelUUID[i],"'}) CREATE (m)-[r:APPLIES]->(t) RETURN r;")
              parameters$downloadDepictPhrase[i] <- paste0(na.omit(parameters$downloadDepictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i], ", theoryDescription: ", parameters$tdscrip[i],"}), (m:Model {modelUUID: '",parameters$theoryModelUUID[i],"'})
CREATE (m)-[r:APPLIES]->(t)
RETURN r;")
              b[i] <- b[i]+1
            }
            else{
              parameters$depictPhrase[i] <- paste0(na.omit(parameters$depictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i],", theoryDescription: ", parameters$tdscrip[i],'}), (e:Element {elementName: "',input[[paste0("theoDepict",i)]][b[i]],'"}) CREATE (t)-[r:INFORMS]->(e) RETURN r;')
              parameters$downloadDepictPhrase[i] <- paste0(na.omit(parameters$downloadDepictPhrase[i]),"MATCH (t:Theory {theoryTitle: ",parameters$theoName[i],", theoryDescription: ", parameters$tdscrip[i],'}), (e:Element {elementName: "',input[[paste0("theoDepict",i)]][b[i]],'"})
CREATE (t)-[r:INFORMS]->(e)
RETURN r;')
              b[i] <- b[i]+1
            }
          }
        }
      }
      output$theory_list <- renderText(paste0("CREATE (:Theory {theoryTitle: ",parameters$theoName, ", theoryDescription: ", parameters$tdscrip[i],"}); ", parameters$depictPhrase,"<b>"))
      downloadStore$theory_list <- paste0("CREATE (:Theory {theoryTitle: ",parameters$theoName, ", theoryDescription: ", parameters$tdscrip[i],"});",
                                          parameters$downloadDepictPhrase)
    }
    if (counterTheory$n == 0) {
      downloadStore$theory_list <- paste(" ")
      output$theory_list <-  renderText(paste( " "))
    }
  })
  
  #Store number of input boxes
  output$counterTheory <- renderPrint(print(counterTheory$n))
  
  #code to generate input boxes
  theoryboxes <- reactive({
    
    n <- counterTheory$n
    
    if (n > 0) {
      # If the no. of boxes previously where more than zero, then
      #save the inputs in those boxes
      if(prevcountTheory$n > 0){
        thName = c()
        depict = c()
        dscrip = c()
        depict_temp = c()
        b = c()
        if(prevcountTheory$n > n){
          lesscnt <- n
          isInc <- FALSE
        }else{
          lesscnt <- prevcountTheory$n
          isInc <- TRUE
        }
        for(i in 1:lesscnt){
          inpTheoryName = paste0("theoName",i)
          thName[i] = input[[inpTheoryName]]
          inpdscrip = paste0("tdscrip",i)
          dscrip[i] = input[[inpdscrip]]
          b[i] <- 1
          while(b[i] <= length(input[[paste0("theoDepict",i)]])){
            if(b[i] < length(input[[paste0("theoDepict",i)]])){
              depict[i] <- paste0(na.omit(depict[i]),input[[paste0("theoDepict",i)]][b[i]],", " )
              b[i] <- b[i]+1
            }else{
              depict[i] <- paste0(na.omit(depict[i]),input[[paste0("theoDepict",i)]][b[i]])
              b[i] <- b[i]+1
            }
          }
        }
        if(isInc){
          thName <- c(thName, input[[paste0("theoName",n)]])
          
          c <- 1
          
          while(c <= length(input[[paste0("theoDepict",n)]])){
            if(c < length(input[[paste0("theoDepict",n)]])){
              depict_temp[n-1] <- paste0(depict_temp[n-1],input[[paste0("theoDepict",n)]][c],", " )
              c <- c+1
              #print(paste0("193: depict_temp = ", depict_temp))
            }else{
              depict_temp[n-1] <- paste0(depict_temp[n-1],input[[paste0("theoDepict",n)]][c])
              #print(paste0("196: depict_temp[n](",n,") is ",depict_temp[n-1]))
              c <- c+1
            }
          }
          
          depict <- c(depict,depict_temp[n-1])
        }
        
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            textInput(inputId = paste0("theoName",i),
                      label = paste0("What is the name of this theory?"), value = thName[i]),
            selectInput(inputId = paste0("theoDepict",i),
                        label = paste0("What item(s) does Theory ",i, " depict/ relate to?"),
                        c("Publication", parameters$modelTitle_select, parameters$elementName_select), #(Please enter each element in single quotes and seprate the elements with a comma)"),
                        selected = strsplit(depict[i], ", ")[[1]],
                        multiple = TRUE),
            textInput(inputId = paste0("tdscrip", i),
                      label = paste0("Describe this theory"), value = dscrip[i]))
        })
        
      }else{
        lapply(seq_len(n), function(i) {
          elementInputs<- tagList(
            textInput(inputId = paste0("theoName",i),
                      label = paste0("What is the name of this theory?"), value = "Theory Name"),
            selectInput(inputId = paste0("theoDepict",i),
                        label = paste0("What item(s) does Theory ",i, " depict/ relate to?"),
                        c("Publication", parameters$modelTitle_select, parameters$elementName_select), #(Please enter each element in single quotes and seprate the elements with a comma)"),
                        multiple = TRUE),
            elementInputs<- tagList(
              textInput(inputId = paste0("tdscrip",i),
                        label = paste0("Describe this theory"))))
        })
      }
      
    }
    
  })
  
  
  
  #display input boxes
  output$theory_ui <- renderUI({ theoryboxes() })
  
  
  ###################################################################################################
  
  output$downloadData <- downloadHandler("cypherScript.txt",
                                         content = function(file){
                                           write(c(downloadStore$pub_out, downloadStore$element_list, downloadStore$def_list, downloadStore$model_list, downloadStore$rel_list, downloadStore$rel_list2, downloadStore$rel_list3, downloadStore$rel_list4, downloadStore$auth_list, downloadStore$theory_list), file)
                                         }
  )
}
